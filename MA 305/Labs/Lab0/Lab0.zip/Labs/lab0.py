#!/usr/bin/env python3

h = 1/2
x = 2/3 - h
y = 3/5 - h
u = (x + x + x) - h
v = (y + y + y + y + y) - h
q = u/v

print()
print('Results from the program: ')
print('h : ', h)
print('x : ', x)
print('y : ', y)
print('u : ', u)
print('v : ', v)
print('q : ', q)
print()

